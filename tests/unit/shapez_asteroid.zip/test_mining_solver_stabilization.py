"""Stabilization-P0/P1: solver_summary once, validation, route probe."""

from __future__ import annotations

import json
from unittest.mock import patch

from django_apps.shapez_asteroid.services.asteroid_mining_layout.final_validation import (
    FinalValidationReport,
    validate_final_mining_layout,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_bundle_commit import (
    Pass12BundleCandidate,
    Pass12LayoutScratch,
    try_commit_pass1_bundle,
    try_commit_pass2_bundle,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_route_probe import (
    bundle_route_probe_or_reject,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.route_probe import (
    probe_stub_cheap_escape_to_external,
    probe_stub_to_external,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.solver_service import (
    build_solver_timeline,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.solver_trace import (
    emit_solver_summary_once,
    trace_event,
    trace_run_id_current,
    trace_run_scope,
)


def test_emit_solver_summary_second_call_is_ignored() -> None:
    calls: list[str] = []

    def fake_trace_event(location: str, message: str, data: dict | None = None) -> None:
        calls.append(message)

    with patch(
        "django_apps.shapez_asteroid.services.asteroid_mining_layout.solver_trace.trace_event",
        fake_trace_event,
    ):
        with trace_run_scope():
            assert emit_solver_summary_once("test", {"run_id": "a", "return_reason": "ok"})
            assert not emit_solver_summary_once("test", {"run_id": "a", "return_reason": "dup"})
    assert calls.count("solver_summary") == 1


def test_trace_event_writes_run_debug_log_folder(tmp_path, monkeypatch, settings) -> None:
    settings.BASE_DIR = tmp_path
    monkeypatch.setenv("SHAPEZ_SOLVER_ALGO_DEBUG", "1")

    with trace_run_scope():
        run_id = trace_run_id_current()
        trace_event("test.location", "test_message", {"value": 3})

    assert run_id is not None
    debug_dir = tmp_path / "var" / "asteroid_mining_layout_debug"
    run_path = debug_dir / f"{run_id}.ndjson"
    latest_path = debug_dir / "latest.ndjson"
    assert run_path.exists()
    assert latest_path.exists()

    records = [json.loads(line) for line in run_path.read_text(encoding="utf-8").splitlines()]
    assert [r["action"] for r in records if r.get("kind") == "action"] == [
        "run_start",
        "run_end",
    ]
    trace_records = [r for r in records if r.get("kind") == "trace"]
    assert trace_records
    assert trace_records[0]["message"] == "test_message"
    assert trace_records[0]["data"]["value"] == 3
    assert latest_path.read_text(encoding="utf-8") == run_path.read_text(encoding="utf-8")


def test_validate_overlap_miner_and_belt_same_cell_invalid() -> None:
    mining_map = [
        {
            "x": 5,
            "y": 5,
            "role": "occupied",
            "surface": "shape",
            "layout_kind": "miner",
            "t": "Layout_ShapeMiner",
        },
        {"x": 5, "y": 5, "role": "belt", "surface": "shape"},
    ]
    r = validate_final_mining_layout(mining_map)
    assert isinstance(r, FinalValidationReport)
    assert r.overlap_violation_count >= 1
    assert not r.geometry_valid


def test_probe_stub_reaches_external_neighbor() -> None:
    transport = frozenset({(2, 0), (3, 0), (4, 0)})
    blocked = frozenset({(1, 0)})
    is_ext = lambda c: c == (5, 0)  # noqa: E731

    assert probe_stub_to_external(
        stub_cell=(2, 0),
        transport_cells=transport,
        blocked_cells=blocked,
        is_external=is_ext,
    )


def test_probe_stub_dead_end() -> None:
    transport = frozenset({(2, 0), (3, 0)})
    blocked: frozenset[tuple[int, int]] = frozenset()
    is_ext = lambda c: c[0] >= 10  # noqa: E731

    assert not probe_stub_to_external(
        stub_cell=(2, 0),
        transport_cells=transport,
        blocked_cells=blocked,
        is_external=is_ext,
    )


def test_probe_cheap_escape_void_reaches_external_when_transport_only_dead_end() -> None:
    transport = frozenset({(1, 0)})
    blocked = frozenset({(-1, 0)})
    is_ext = lambda c: c[0] > 5  # noqa: E731

    assert not probe_stub_to_external(
        stub_cell=(1, 0),
        transport_cells=transport,
        blocked_cells=blocked,
        is_external=is_ext,
    )
    assert probe_stub_cheap_escape_to_external(
        stub_cell=(1, 0),
        transport_cells=transport,
        blocked_cells=blocked,
        is_external=is_ext,
        allowed_void_cells=frozenset((x, 0) for x in range(-5, 16) if x != 0),
    )


def test_bundle_route_pass1_cheap_escape_succeeds_without_transport_path() -> None:
    transport = frozenset({(1, 0)})
    blocked = frozenset({(-1, 0)})
    is_ext = lambda c: c[0] > 5  # noqa: E731
    assert bundle_route_probe_or_reject(
        (1, 0),
        transport_cells=transport,
        blocked_cells=blocked,
        is_external=is_ext,
        trace_location="test.p1",
        pass1_allow_cheap_escape=True,
        p1_cheap_void_cells=frozenset((x, 0) for x in range(-5, 16) if x != 0),
    )


def test_bundle_route_without_cheap_fails_when_only_void_path_exists() -> None:
    transport = frozenset({(1, 0)})
    blocked = frozenset({(-1, 0)})
    is_ext = lambda c: c[0] > 5  # noqa: E731
    rejected: list[dict] = []

    def capture_reject(loc: str, data: dict | None) -> None:
        rejected.append({"loc": loc, "data": data or {}})

    with patch(
        "django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_route_probe."
        "trace_bundle_reject_no_route",
        capture_reject,
    ):
        ok = bundle_route_probe_or_reject(
            (1, 0),
            transport_cells=transport,
            blocked_cells=blocked,
            is_external=is_ext,
            trace_location="test.pass2",
            pass1_allow_cheap_escape=False,
        )
    assert not ok
    assert rejected


def test_bundle_route_probe_or_reject_traces_failure() -> None:
    rejected: list[dict] = []

    def capture_reject(loc: str, data: dict | None) -> None:
        rejected.append({"loc": loc, "data": data or {}})

    transport = frozenset({(2, 0)})
    blocked: frozenset[tuple[int, int]] = frozenset()
    is_ext = lambda c: c[0] >= 100  # noqa: E731

    with patch(
        "django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_route_probe."
        "trace_bundle_reject_no_route",
        capture_reject,
    ):
        ok = bundle_route_probe_or_reject(
            (2, 0),
            transport_cells=transport,
            blocked_cells=blocked,
            is_external=is_ext,
            trace_location="test.bundle",
            bundle_hint={"bid": "x"},
        )
    assert not ok
    assert rejected and rejected[0]["loc"] == "test.bundle"


def test_build_solver_timeline_empty_bp() -> None:
    decoded: dict = {"BP": {"Entries": []}}
    out = build_solver_timeline(decoded)
    assert out["return_reason"] == "ok"
    assert out["solver_summary"]["capacity_mode"] == "accumulate_only"
    assert out["solver_summary"]["geometry_valid"] is True


def test_pass1_reject_leaves_no_transport_or_blocked_residue() -> None:
    st = Pass12LayoutScratch(transport_cells={(10, 0)}, blocked_cells={(1, 0)})
    before_t, before_b = set(st.transport_cells), set(st.blocked_cells)
    before_x, before_e = set(st.extractor_cells), dict(st.extension_facings)
    before_od = dict(st.extractor_output_dirs)
    cand = Pass12BundleCandidate(
        blocked_cells=frozenset({(8, 0)}),
        new_transport=frozenset({(2, 0), (3, 0)}),
        stub_cell=(2, 0),
    )
    is_ext = lambda c: c[0] >= 20  # noqa: E731
    assert not try_commit_pass1_bundle(st, cand, is_external=is_ext)
    assert st.transport_cells == before_t
    assert st.blocked_cells == before_b
    assert st.extractor_cells == before_x
    assert st.extension_facings == before_e
    assert st.extractor_output_dirs == before_od


def test_pass1_commit_applies_delta_when_route_exists() -> None:
    st = Pass12LayoutScratch(transport_cells=set(), blocked_cells={(1, 0)})
    cand = Pass12BundleCandidate(
        blocked_cells=frozenset({(9, 0)}),
        new_transport=frozenset({(2, 0), (3, 0), (4, 0)}),
        stub_cell=(2, 0),
    )
    is_ext = lambda c: c[0] >= 5 and c[1] == 0  # noqa: E731
    assert try_commit_pass1_bundle(st, cand, is_external=is_ext)
    assert (2, 0) in st.transport_cells and (9, 0) in st.blocked_cells


def test_pass1_reject_emits_bundle_reject_no_route() -> None:
    rejected: list[str] = []

    def capture_reject(loc: str, data: dict | None) -> None:
        rejected.append(loc)

    st = Pass12LayoutScratch(transport_cells={(10, 0)}, blocked_cells=set())
    cand = Pass12BundleCandidate(
        blocked_cells=frozenset({(8, 0)}),
        new_transport=frozenset({(2, 0)}),
        stub_cell=(2, 0),
    )
    is_ext = lambda c: c[0] >= 100  # noqa: E731
    with patch(
        "django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_route_probe."
        "trace_bundle_reject_no_route",
        capture_reject,
    ):
        assert not try_commit_pass1_bundle(st, cand, is_external=is_ext)
    assert rejected == ["pass12_bundle_commit.try_commit_pass1_bundle"]


def test_pass1_invalid_stub_emits_bundle_reject_invalid_stub() -> None:
    invalid_calls: list[str] = []

    def capture_invalid(loc: str, data: dict | None) -> None:
        invalid_calls.append(loc)

    st = Pass12LayoutScratch(transport_cells=set(), blocked_cells=set())
    cand = Pass12BundleCandidate(
        blocked_cells=frozenset({(9, 0)}),
        new_transport=frozenset({(2, 0), (3, 0)}),
        stub_cell=(5, 0),
    )
    is_ext = lambda c: True  # noqa: E731
    with patch(
        "django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_bundle_commit."
        "trace_bundle_reject_invalid_stub",
        capture_invalid,
    ):
        assert not try_commit_pass1_bundle(st, cand, is_external=is_ext)
    assert invalid_calls == ["pass12_bundle_commit.try_commit_pass1_bundle"]
    assert st.transport_cells == set() and st.blocked_cells == set()


def test_pass2_commit_uses_pass2_trace_location() -> None:
    locations: list[str] = []

    def spy_probe(
        stub_cell: tuple[int, int],
        *,
        transport_cells: frozenset[tuple[int, int]],
        blocked_cells: frozenset[tuple[int, int]],
        is_external,
        trace_location: str,
        bundle_hint: dict | None = None,
        pass1_allow_cheap_escape: bool = False,
        p1_cheap_void_cells: frozenset[tuple[int, int]] | None = None,
    ) -> bool:
        locations.append(trace_location)
        return True

    st = Pass12LayoutScratch()
    cand = Pass12BundleCandidate(
        blocked_cells=frozenset({(9, 0)}),
        new_transport=frozenset({(2, 0), (3, 0)}),
        stub_cell=(2, 0),
    )
    is_ext = lambda c: True  # noqa: E731
    with patch(
        "django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_bundle_commit."
        "bundle_route_probe_or_reject",
        spy_probe,
    ):
        assert try_commit_pass2_bundle(st, cand, is_external=is_ext)
    assert locations == ["pass12_bundle_commit.try_commit_pass2_bundle"]


def test_rejected_pass1_then_timeline_single_solver_summary_and_quarantine_zero() -> None:
    summary_msgs: list[str] = []

    def trace_cap(location: str, message: str, data: dict | None = None) -> None:
        if message == "solver_summary":
            summary_msgs.append(message)

    st = Pass12LayoutScratch(transport_cells={(10, 0)}, blocked_cells=set())
    cand = Pass12BundleCandidate(
        blocked_cells=frozenset({(8, 0)}),
        new_transport=frozenset({(2, 0)}),
        stub_cell=(2, 0),
    )
    is_ext = lambda c: c[0] >= 100  # noqa: E731
    with patch(
        "django_apps.shapez_asteroid.services.asteroid_mining_layout.solver_trace.trace_event",
        trace_cap,
    ):
        with trace_run_scope():
            assert not try_commit_pass1_bundle(st, cand, is_external=is_ext)
            out = build_solver_timeline({"BP": {"Entries": []}})
    assert summary_msgs.count("solver_summary") == 1
    assert out["solver_summary"]["quarantined_unrouted_count"] == 0
