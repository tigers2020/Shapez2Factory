"""Pass2-A internal fill: inner-first sweep, ``try_commit_pass2_bundle`` only."""

from __future__ import annotations

from functools import wraps
from unittest.mock import patch

from django_apps.shapez_asteroid.services.asteroid_mining_layout import (
    pass2_internal_placement as p2,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.boundary import (
    cells_touching_void,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.pass2_internal_placement import (
    mineable_inner_first_order,
    run_pass2_internal_placement_mvp,
    try_place_pass2_internal_bundle,
)
from django_apps.shapez_asteroid.services.asteroid_mining_layout.pass12_bundle_commit import (
    Pass12LayoutScratch,
    try_commit_pass2_bundle,
)


def test_mineable_inner_first_partition_matches_complement() -> None:
    """Order is sorted inner, then sorted perimeter (mineable ∩ touching_void)."""

    ast = frozenset(
        {
            (-2, -1),
            (-2, 0),
            (-2, 1),
            (-1, -1),
            (-1, 0),
            (-1, 1),
            (1, -1),
            (1, 0),
            (1, 1),
            (2, -1),
            (2, 0),
            (2, 1),
        }
    )
    mine = ast
    ordered = mineable_inner_first_order(mine, ast)
    perimeter = mine & frozenset(cells_touching_void(set(ast)))
    inner = mine - perimeter
    k = len(inner)
    assert ordered[:k] == tuple(sorted(inner, key=lambda c: (c[0], c[1])))
    assert ordered[k:] == tuple(sorted(perimeter, key=lambda c: (c[0], c[1])))
    assert set(ordered) == mine


def test_pass2_places_when_free_cell_exists() -> None:
    asteroid = frozenset({(-1, 0), (1, 0)})
    mineable = asteroid
    scratch = Pass12LayoutScratch()
    is_ext = lambda c: c not in asteroid  # noqa: E731

    n = run_pass2_internal_placement_mvp(
        mineable_cells=mineable,
        asteroid_cells=asteroid,
        scratch=scratch,
        is_external=is_ext,
    )
    assert n >= 1
    assert scratch.extractor_cells
    assert scratch.transport_cells


def test_try_commit_pass2_bundle_is_invoked_not_bypassed() -> None:
    asteroid = frozenset({(-1, 0), (1, 0)})
    mineable = asteroid
    scratch = Pass12LayoutScratch()
    is_ext = lambda c: c not in asteroid  # noqa: E731

    commit_calls: list[int] = []

    @wraps(try_commit_pass2_bundle)
    def wrapped(*args, **kwargs):  # type: ignore[no-untyped-def]
        commit_calls.append(1)
        return try_commit_pass2_bundle(*args, **kwargs)

    with patch.object(p2, "try_commit_pass2_bundle", wrapped):
        run_pass2_internal_placement_mvp(
            mineable_cells=mineable,
            asteroid_cells=asteroid,
            scratch=scratch,
            is_external=is_ext,
        )
    assert sum(commit_calls) >= 1


def test_pass2_route_impossible_leaves_no_residue() -> None:
    asteroid = frozenset({(-1, 0)})
    mineable = asteroid
    scratch = Pass12LayoutScratch()
    is_ext = lambda c: c[0] >= 50  # noqa: E731

    before_t, before_b = set(scratch.transport_cells), set(scratch.blocked_cells)
    n = run_pass2_internal_placement_mvp(
        mineable_cells=mineable,
        asteroid_cells=asteroid,
        scratch=scratch,
        is_external=is_ext,
    )
    assert n == 0
    assert scratch.transport_cells == before_t
    assert scratch.blocked_cells == before_b
    assert scratch.extractor_cells == set()
    assert scratch.extension_facings == {}
    assert scratch.extractor_output_dirs == {}


def test_pass2_skips_pass1_extractor_body() -> None:
    scratch = Pass12LayoutScratch()
    scratch.blocked_cells = {(-1, 0)}
    scratch.extractor_cells = {(-1, 0)}
    scratch.transport_cells = {(1, 0)}
    scratch.extractor_output_dirs = {(-1, 0): (1, 0)}
    mineable = frozenset({(-1, 0), (2, 0)})
    asteroid = mineable
    is_ext = lambda c: c not in mineable  # noqa: E731

    n = run_pass2_internal_placement_mvp(
        mineable_cells=mineable,
        asteroid_cells=asteroid,
        scratch=scratch,
        is_external=is_ext,
    )
    assert n == 1
    assert (-1, 0) in scratch.extractor_cells
    assert (2, 0) in scratch.extractor_cells


def test_pass2_skips_pass1_extension_cell() -> None:
    scratch = Pass12LayoutScratch()
    scratch.blocked_cells = {(-1, 0), (1, 0)}
    scratch.extractor_cells = {(-1, 0)}
    scratch.transport_cells = {(2, 0)}
    scratch.extractor_output_dirs = {(-1, 0): (1, 0)}
    scratch.extension_facings = {(1, 0): (-1, 0)}
    mineable = frozenset({(-1, 0), (1, 0), (-1, 1)})
    asteroid = frozenset({(-1, 0), (1, 0), (2, 0), (-1, 1), (-2, 0)})
    is_ext = lambda c: c not in asteroid  # noqa: E731

    n = run_pass2_internal_placement_mvp(
        mineable_cells=mineable,
        asteroid_cells=asteroid,
        scratch=scratch,
        is_external=is_ext,
    )
    assert n >= 1
    assert (1, 0) not in scratch.extractor_cells


def test_pass2_skips_committed_transport_stub_slot() -> None:
    scratch = Pass12LayoutScratch()
    scratch.transport_cells = {(1, 0)}
    mineable = frozenset({(1, 0), (-1, 0)})
    asteroid = mineable
    is_ext = lambda c: c not in asteroid  # noqa: E731

    n = run_pass2_internal_placement_mvp(
        mineable_cells=mineable,
        asteroid_cells=asteroid,
        scratch=scratch,
        is_external=is_ext,
    )
    assert n == 1
    assert (-1, 0) in scratch.extractor_cells


def test_pass2_respects_hard_barrier_cells() -> None:
    scratch = Pass12LayoutScratch()
    mineable = frozenset({(-1, 0), (1, 0)})
    asteroid = mineable
    is_ext = lambda c: c not in asteroid  # noqa: E731
    barriers = frozenset({(-1, 0)})

    n = run_pass2_internal_placement_mvp(
        mineable_cells=mineable,
        asteroid_cells=asteroid,
        scratch=scratch,
        is_external=is_ext,
        hard_barrier_cells=barriers,
    )
    assert n == 1
    assert (-1, 0) not in scratch.extractor_cells
    assert (1, 0) in scratch.extractor_cells


def test_try_place_pass2_stub_blocked_skips_direction() -> None:
    """When every cardinal stub slot is blocked, placement fails without partial commit."""

    scratch = Pass12LayoutScratch()
    scratch.transport_cells = {(1, 0), (-2, 0), (-1, -1), (-1, 1)}
    mineable = frozenset({(-1, 0)})
    is_ext = lambda c: True  # noqa: E731

    assert not try_place_pass2_internal_bundle(
        extractor_cell=(-1, 0),
        mineable_cells=mineable,
        scratch=scratch,
        is_external=is_ext,
        hard_barrier_cells=frozenset(),
    )
    assert scratch.extractor_cells == set()
